#include <iostream>
#include <iomanip>
#include "RetailItem.h"
using namespace std;

int main() {
    RetailItem item;
    item.crtItem();
}