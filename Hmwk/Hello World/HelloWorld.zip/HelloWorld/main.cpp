/* 
 * File:   main.cpp
 * Author: Joshua Grizzell
 *
 * Created on February 23, 2021, 2:52 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    cout << "Hello, world!";
    
    return 0;
}

