#include <iostream>
using namespace std;

class Hand{
  protected:
    string cards[10];
    int drawn, score;
    static const string suit[4];
    static const string face[13];
    static const int ms;
  public:
    Hand(){
      int drawn = 0;
      int score = 0;
    }
    Hand(string c[10], int d, int s){
      for(int i = 0; i < 10; i++){
        cards[i] = c[i];
      }
      drawn = d;
      score = s % 10;
    }
    int getDrwn() { return drawn; }
    int getScre() { return score; }
    string getCard(int index) { return cards[index]; }
    void setDrwn(int d) { drawn = d; }
    void setScre(int s) { score = s % 10; }
    void setCard(string card, int index) { cards[index] = card; } 

    string drwCard();
    int cardVal(string strCard);
    bool repeat(int o, string card, string *deck);

    Hand operator ++ (int);
    Hand operator -- (int);
};