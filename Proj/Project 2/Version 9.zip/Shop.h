#ifndef SHOP_H
#define SHOP_H
#include "Item.h"
#include "PlayerData.h"

class Shop{
  protected:
    static Item item[9];
  public:
    friend class PlayerData;
    //Constructor (defined in Shop.cpp)
    Shop(bool isNew);
    //Inline function (defined in Shop.cpp as well)
    void prnShop(PlayerData pd);
};

#endif