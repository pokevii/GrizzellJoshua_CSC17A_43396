#ifndef PLAYERDATA_H
#define PLAYERDATA_H

#include <iostream>
#include <cstring>
using namespace std;

class PlayerData{
  protected: 
    static float money;
    char name[25];
    int wins, losses, ties, betWon, betLost;
    float gains;
    static bool bought[5];
  public:
    class NoDataFound { };
    friend class Shop;
  //Constructors
    PlayerData(){
      money = 0;
      wins = 0;
      losses = 0;
      ties = 0;
      betWon = 0;
      betLost = 0;
    }
    PlayerData(float m, string nam, int w, int l, int t, int bw, int bl, float g){
      money = m;
      strcpy(name, nam.c_str());
      wins = w;
      losses = l;
      ties = t;
      betWon = bw;
      betLost = bl;
      gains = g;
    }
    ~PlayerData(){
      //Destructor here
    }

    //Accessors
    float getMny() { return money; }
    char* getNam() { return name; }
    float getGain() { return gains; }
    int getWins() { return wins; }
    int getLoss() { return losses; }
    int getTies() { return ties; }
    int getBWon() { return betWon; }
    int getBLst() { return betLost; }
    bool getItem(int index) { return bought[index]; }

    //Mutators
    void setMny(float m) { money = m; }
    void setNam(char* n) { strcpy(name, n); }
    void setGain(float g) { gains = g; }
    void setWins(int w) { wins = w; }
    void setLoss(int l) { losses = l; }
    void setTies(int t) { ties = t; }
    void setBWon(int bw) { betWon = bw; }
    void setBLst(int bl) { betLost = bl; }
    void setItem(bool b, int index) { bought[index] = b; }

    //Function Prototypes
    void DispDat();
    void DelDat();
    void Load();
    void Save();
    void WonBet();
    void LostBet();
    void WonGame();
    void LstGame();
    void TieGame();
    void AddGns(float g);

    //Operator Overloads
    PlayerData operator += (const PlayerData &other);
    PlayerData operator -= (const PlayerData &other);
};

#endif