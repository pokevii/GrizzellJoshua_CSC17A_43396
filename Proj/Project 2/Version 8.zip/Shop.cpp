#include "Shop.h"
#include <iostream>
#include <iomanip>
using namespace std;

Shop::Shop(bool isNew){
  if(isNew){
    item[0] = {
      "Prettier Stats Page",
      "Get some fancy ASCII art on your stats page!",
      2000,
      false 
    };
    item[1] = {
      "Name Change",
      "Don't like your name? Go ahead, change it! For a price...",
      3000,
      false
    };
    item[2] = {
      "Story Mode",
      "Looking for a story in your simple game of Baccarat? Look no further!",
      3333.33,
      false
    };
    item[3] = {
      "More Betting Options",
      "Bet on whether or not the player or dealer gets a pair. This returns 12x the wager!",
      4000,
      false
    };
    item[4] = {
      "Big Head Mode",
      "This does nothing. There are no heads in this game. Spend money on it anyway.",
      3.14,
      false
    };
  } else {
    cout << "Load in things here.";
  }
}

//This prints the shop and allows the user to purchase items from it.
//This function made me make "money" a static variable. It should have been from the start, honestly.
void Shop::prnShop(PlayerData pd){ 
  int menuNum;
  char rspnse;

  cout << setprecision(2) << fixed;
  cout << "==================SHOP==================\n";
  for(int i = 0; i < 5; i++){
    if(pd.bought[i] == true){
      cout << "[X] ";
    }
    cout << i+1 << ". " << setw(25) << left << item[i].getName() << "$" << setw(10) << item[i].getPrice() << endl;
  }
  cin >> menuNum;
  Item curItem = item[menuNum-1];
  cout << curItem.getDesc() << endl;

  //If the player already has this item, get 'em outta here.
  if(pd.bought[menuNum-1] == true){
    cout << "You already have this item!\n\n";
    return;
  }

  cout << "This item costs $" << curItem.getPrice() << ". ";
  cout << "You have $" << pd.money << ".\n";

  //Check if user can afford the item
  if(curItem.getPrice() > pd.money){
    cout << "Unfortunately, you cannot afford this at the moment. Come back another time.\n\n";
  } else {
    do{
      cout << "Would you like to purchase this item? (Y/N): ";
      cin >> rspnse;
    }while(rspnse != 'Y' && rspnse != 'N');
    if(rspnse == 'Y'){
      pd.money -= curItem.getPrice();
      pd.setItem(true, menuNum-1);
      curItem.setBght(true);
      item[menuNum-1] = curItem;
      cout << "Item successfully purchased. Enjoy!\n\n";
    } else {
      cout << "Aww, how unfortunate. Oh, well.\n\n";
    }
  }
}