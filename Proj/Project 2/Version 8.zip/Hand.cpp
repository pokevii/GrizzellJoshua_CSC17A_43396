#include <iostream>
#include "Hand.h"
using namespace std;

const string Hand::suit[4] = {" of Clubs", " of Hearts", " of Spades", " of Diamonds"};
const string Hand::face[13] = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
const int Hand::ms = 1000000;

string Hand::drwCard(){
  string card;
  int suitNum, faceNum;
  
  faceNum = rand() % 13;
  suitNum = rand() % 4;

  card = face[faceNum] + suit[suitNum];

  return card;
}

int Hand::cardVal(string strCard){
  int value = -1;
  
  for(int i = 0; i < 13; i++){
    for(int j = 0; j < 4; j++){
      if(strCard == face[i] + suit[j]){
        value = i+1;
        //If the card is a jack, queen, or king, set the value to 0.
        if(value >= 10 && value <= 13){
          value = 0;
        }
      }
    }
  }
  //cout << value << " has been added to their score.\n";
  return value;
}

bool Hand::repeat(int o, string card, string *deck){
  bool same = false;
  for(int i = 0; i <= o; i++){
    if(deck[i] == card){
      same = true;
      break;
    }
  }
  return same;
}

Hand Hand::operator ++ (int){
  Hand temp(cards, score, drawn);
  temp.drawn = drawn + 1;
  return temp;
}

Hand Hand::operator -- (int){
  Hand temp(cards, score, drawn);
  temp.drawn = drawn - 1;
  return temp;
}