#include <iostream>
#include <iomanip>
#include "LastGame.h"
using namespace std;

void LastGame::dispLG(){
  if(date == ""){
    cout << "No previous game found! Go play a match, dummy.\n\n";
    return;
  }

  cout << "=========================\n";
  cout << "Previous Game on " << date << endl;
  cout << "Player's Hand:\n";
  cout << left;
  for(int i = 0; i < player.getDrwn(); i++){
    cout << setw(5) << player.getCard(i) << endl;
  }
  cout << "Score: " << player.getScre() % 10;
  if(player.getScre() == 8 || player.getScre() == 9){
    cout << " (Natural)";
  }

  cout << "\n\nDealer's Hand:\n";
  for(int i = 0; i < dealer.getDrwn(); i++){
    cout << setw(5) << dealer.getCard(i) << endl;
  }
  cout << "Score: " << dealer.getScre() % 10;
  if(dealer.getScre() == 8 || dealer.getScre() == 9){
    cout << " (Natural)";
  }
  cout << "\n\nWINNER: " << winner << "\n";
  cout << "=========================\n\n";
}

void LastGame::fillDat(Hand p, Hand d){
  time_t curTime;
  time(&curTime);

  player = p;
  dealer = d;

  if(player.getScre() > dealer.getScre()){
    cout << "PLAYER WINS!\n\n";
    winner = "Player";
  } else if (dealer.getScre() > player.getScre()){
    cout << "DEALER WINS!\n\n";
    winner = "Dealer";
  } else {
    cout << "TIE!!!\n\n";
    winner = "Tie";
  }

  date = ctime(&curTime);
}

