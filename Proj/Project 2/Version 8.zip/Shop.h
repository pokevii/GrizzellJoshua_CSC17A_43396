#ifndef SHOP_H
#define SHOP_H
#include "Item.h"
#include "PlayerData.h"

class Shop{
  protected:
    static Item item[9];
  public:
    friend class PlayerData;
    Shop(bool isNew);
    void prnShop(PlayerData pd);
};

#endif